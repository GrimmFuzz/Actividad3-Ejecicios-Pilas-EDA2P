let cola = [];
let pila = [];

function mostrarCola() {
    document.getElementById('resultado').innerHTML = '';
    cola = [];

    const palabra = document.getElementById('palabra').value.trim();
    const regexSoloLetras = /^[a-zA-Z\s]+$/;

    if (palabra.length === 0) {
        alert('Primero ingrese una palabra.');
        return;
    }

    if (!regexSoloLetras.test(palabra)) {
        alert('La palabra solo debe contener letras y espacios.');
        return;
    }

    // Agregar cada letra de la palabra a la cola
    for (let i = 0; i < palabra.length; i++) {
        cola.push(palabra[i]);
    }

    // Mostrar la palabra original e invertirla
    let palabraOriginal = cola.join('');
    let palabraInvertida = '';

    while (cola.length > 0) {
        palabraInvertida += cola.pop();
    }

    // Mostrar el resultado en el DOM
    document.getElementById('resultado').innerHTML = `
        <p>Palabra escrita: "${palabraOriginal}".</p>
        <p>Palabra invertida: "${palabraInvertida}".</p>`;
    
    document.getElementById('palabra').value = ''; 
    document.getElementById('formularioIngreso').style.display = 'none';
}

function verificarPalindromopalindromo() {
    document.getElementById('resultado').innerHTML = '';
    
    const palabra = document.getElementById('palabrapalindromo').value.trim().toLowerCase();
    const regexSoloLetras = /^[a-zA-Z\s]+$/;

    if (palabra.length === 0) {
        alert('Primero ingrese una palabra.');
        return;
    }

    if (!regexSoloLetras.test(palabra)) {
        alert('La palabra solo debe contener letras y espacios.');
        return;
    }

    const palabraSinEspacios = palabra.replace(/\s+/g, '');
    const palabraInvertida = palabraSinEspacios.split('').reverse().join('');

    if (palabraSinEspacios === palabraInvertida) {
        document.getElementById('resultado').innerHTML = `
            <p>La palabra "${palabra}" es un palíndromo.</p>
            <p>Palabra invertida: "${palabraInvertida}".</p>`;
    } else {
        document.getElementById('resultado').innerHTML = `
            <p>La palabra "${palabra}" no es un palíndromo.</p>
            <p>Palabra invertida: "${palabraInvertida}".</p>`;
    }

    document.getElementById('palabrapalindromo').value = ''; 
    document.getElementById('formularioIngreso1').style.display = 'none';
}

function mostrarPila() {

    // Limpiar el resultado previo
    document.getElementById('resultado').innerHTML = '';
    pila = [];

    const valoresInput = document.getElementById('valoresPila').value.trim();

    // Validación para asegurar que el campo no esté vacío
    if (valoresInput === '') {
        alert('Por favor ingrese al menos un valor.');
        return;
    }

    const valores = valoresInput.split(',').map(Number);

    // Validación para asegurar que todos los valores sean números enteros válidos
    if (valores.some(isNaN)) {
        alert('Por favor ingrese valores enteros válidos.');
        return;
    }

    // Validación para asegurar que no se ingresen números negativos
    if (valores.some(valor => valor < 0)) {
        alert('No se permiten valores negativos.');
        return;
    }

    // Guardar los valores en la pila
    pila = valores;

    // Mostrar la pila ingresada
    document.getElementById('resultado').innerHTML = `<p>Valores ingresados en la pila: ${pila.join(', ')}</p>`;

    // Ocultar el formulario de ingreso y mostrar el formulario de reemplazo
    document.getElementById('Pila').style.display = 'none';
    document.getElementById('formularioReemplazo').style.display = 'block';
}


// Función para reemplazar valores en la pila
function reemplazarValorPila() {
    const valorViejo = parseInt(document.getElementById('valorViejo').value);
    const valorNuevo = parseInt(document.getElementById('valorNuevo').value);

    // Validación para asegurar que ambos valores son enteros y no negativos
    if (isNaN(valorViejo) || isNaN(valorNuevo)) {
        alert('Por favor ingrese valores enteros válidos para el reemplazo.');
        return;
    }

    if (valorViejo < 0 || valorNuevo < 0) {
        alert('No se permiten valores negativos.');
        return;
    }

    let pilaTemp = [];

    // Reemplazar valores en la pila
    while (pila.length > 0) {
        let valor = pila.pop();
        if (valor === valorViejo) {
            pilaTemp.push(valorNuevo);
        } else {
            pilaTemp.push(valor);
        }
    }

    while (pilaTemp.length > 0) {
        pila.push(pilaTemp.pop());
    }

    document.getElementById('resultado').innerHTML += `<p>Valores después del reemplazo: ${pila.join(', ')}</p>`;

    // Limpiar campos de entrada
    document.getElementById('valorViejo').value = '';
    document.getElementById('valorNuevo').value = '';
    document.getElementById('formularioReemplazo').style.display = 'none';
    document.getElementById('valoresPila').value = ''; 
}


function handleClick(action) {

    document.getElementById('resultado').innerHTML = '';
    document.getElementById('Pila').style.display = 'none';
    document.getElementById('Invertir').style.display = 'none';
    document.getElementById('Sumar').style.display = 'none';
    document.getElementById('Palindromo').style.display = 'none';

    switch (action) {
        case 'Pila':
            document.getElementById('Pila').style.display = 'block';
            break;
        case 'Palíndromo':
            document.getElementById('Palindromo').style.display = 'block';
            break;
        case 'Sumar':
            document.getElementById('Sumar').style.display = 'block';
            break;
        case 'Invertir':
            document.getElementById('Invertir').style.display = 'block';
            break;
    }
}

function sumarNumerosGrandes() {
    document.getElementById('resultado').innerHTML = '';
    
    const numero1 = document.getElementById('numero1').value.trim();
    const numero2 = document.getElementById('numero2').value.trim();

    if (!/^\d+$/.test(numero1) || !/^\d+$/.test(numero2)) {
        alert('Por favor ingrese solo números positivos.');
        return;
    }

    const pila1 = numero1.split('').map(Number).reverse();
    const pila2 = numero2.split('').map(Number).reverse();
    const resultadoPila = [];
    
    let carry = 0;
    while (pila1.length > 0 || pila2.length > 0 || carry > 0) {
        const digito1 = pila1.length > 0 ? pila1.pop() : 0;
        const digito2 = pila2.length > 0 ? pila2.pop() : 0;
        const suma = digito1 + digito2 + carry;

        resultadoPila.push(suma % 10);
        carry = Math.floor(suma / 10);
    }

    const resultado = resultadoPila.reverse().join('');
    document.getElementById('resultado').innerHTML = `<p>Resultado de la suma: ${resultado}</p>`;
    document.getElementById('numero1').value = '';
    document.getElementById('numero2').value = '';
}

